# Copyright: Ankitects Pty Ltd and contributors
# License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html

# Legacy code expects to find Collection in this module.

from anki.collection import Collection

_Collection = Collection
