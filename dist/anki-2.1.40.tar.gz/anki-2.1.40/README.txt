This is an individual "anki" python wheel package for all platforms. Source codes are cloned from https://github.com/ankitects/anki
